import sqlite3
import smtplib
import ssl
import random
import string
import datetime
import os
import bcrypt
import sys  # For command-line arguments

# Setup Logging
import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

# ✅ Zoho Mail SMTP Configuration
SMTP_SERVER = "smtp.zoho.in"  # Use "smtp.zoho.com" if you're using Zoho Global
SMTP_PORT = 465

# ✅ Securely fetch credentials from environment variables
SENDER_EMAIL = os.getenv("ZOHO_EMAIL")  # Set this in the environment
SENDER_PASSWORD = os.getenv("ZOHO_PASS")  # Use App Password from Zoho

# ✅ SQLite Database Path
DB_PATH = "database.db"

# ✅ Updated Password Reset Link with Real Domain
WEBSITE_BASE_URL = "http://localhost:3000"
  # ✅ UPDATED TO YOUR DOMAIN

# ------------------ Helper Functions ------------------

def generate_reset_token(length=32):
    """Generates a secure random password reset token."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def hash_password(password):
    """Hashes a password using bcrypt for security."""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def verify_password(plain_password, hashed_password):
    """Verifies a password against its hashed version."""
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

def send_reset_email(email, reset_link):
    """Sends a password reset email using Zoho Mail SMTP."""
    subject = "Password Reset Request - Redpill Fitness"
    body = f"""
    You requested a password reset.

    Click the link below to reset your password:
    {reset_link}

    This link expires in 24 hours.

    If you did not request this, ignore this email.

    Best,
    Redpill Fitness Support Team
    """

    message = f"Subject: {subject}\n\n{body}"

    context = ssl.create_default_context()
    try:
        with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, context=context) as server:
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            server.sendmail(SENDER_EMAIL, email, message)
        logging.info("✅ Password reset email sent successfully!")
    except Exception as e:
        logging.error(f"❌ Error sending email: {e}")

# ------------------ Password Reset Process ------------------

def request_password_reset(user_email):
    """Handles password reset request: generates token & sends reset email."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # Check if user exists
        cursor.execute("SELECT user_id FROM users WHERE email = ?", (user_email,))
        user = cursor.fetchone()

        if not user:
            logging.warning("⚠️ User not found.")
            return False

        user_id = user[0]
        reset_token = generate_reset_token()
        expiry_time = datetime.datetime.utcnow() + datetime.timedelta(hours=24)

        # Store reset token & expiry in the database
        cursor.execute("UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE user_id = ?",
                       (reset_token, expiry_time.isoformat(), user_id))
        conn.commit()

        # ✅ Corrected Reset Link
        reset_link = f"{WEBSITE_BASE_URL}/reset_password?token={reset_token}&email={user_email}"
        send_reset_email(user_email, reset_link)

        logging.info(f"✅ Password reset request processed. Link: {reset_link}")
        return True

    except sqlite3.Error as e:
        logging.error(f"❌ Database error: {e}")
        return False
    finally:
        if conn:
            conn.close()

def reset_password(reset_token, new_password):
    """Resets the user's password if the token is valid."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute("SELECT user_id, reset_token_expiry FROM users WHERE reset_token = ?", (reset_token,))
        result = cursor.fetchone()

        if not result:
            logging.warning("❌ Invalid reset token.")
            return False

        user_id, expiry_str = result
        expiry_time = datetime.datetime.fromisoformat(expiry_str)

        if datetime.datetime.utcnow() > expiry_time:
            logging.warning("❌ Reset token expired.")
            return False

        # Hash the new password
        hashed_password = hash_password(new_password)

        # Update the password and invalidate the reset token
        cursor.execute("UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE user_id = ?",
                       (hashed_password, user_id))
        conn.commit()

        logging.info("✅ Password reset successfully!")
        return True

    except sqlite3.Error as e:
        logging.error(f"❌ Database error: {e}")
        return False
    finally:
        if conn:
            conn.close()

# ------------------ Command-Line Interface ------------------

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("❌ Usage: python password_reset.py <request/reset> <email/token> <new_password>")
        sys.exit(1)

    action = sys.argv[1]

    if action == "request":
        if len(sys.argv) < 3:
            print("❌ Usage: python password_reset.py request <email>")
            sys.exit(1)

        user_email = sys.argv[2]
        if not request_password_reset(user_email):
            sys.exit(1)

    elif action == "reset":
        if len(sys.argv) < 4:
            print("❌ Usage: python password_reset.py reset <token> <new_password>")
            sys.exit(1)

        token = sys.argv[2]
        new_password = sys.argv[3]
        if not reset_password(token, new_password):
            sys.exit(1)

    else:
        print("❌ Invalid action. Use 'request' or 'reset'.")
        sys.exit(1)

    sys.exit(0)
