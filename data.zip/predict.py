import sys
import numpy as np
from PIL import Image
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import os
import joblib  # For saving and loading the model

MODEL_FILENAME = 'knn_model.joblib'
SCALER_FILENAME = 'scaler.joblib'
DATA_DIR = 'data'  # Relative path to the data directory (adjust if needed)


def preprocess_image(image_path):
    try:
        image = Image.open(image_path).convert('L')
        image = image.resize((64, 64))
        return np.array(image).flatten()
    except FileNotFoundError as e:
        print(f"Error: Image not found at {image_path}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"Error preprocessing image: {e}", file=sys.stderr)  # Print to stderr
        return None


def load_training_data(data_dir):
    folder_paths = [os.path.join(data_dir, 'cardio_low_carb'),
                    os.path.join(data_dir, 'strength_high_protein')]
    images, labels = [], []
    for folder_path in folder_paths:
        for filename in os.listdir(folder_path):
            filepath = os.path.join(folder_path, filename)
            if os.path.isfile(filepath):
                img_data = preprocess_image(filepath)
                if img_data is not None:  # Only add if preprocessing was successful
                    images.append(img_data)
                    labels.append(0 if 'cardio_low_carb' in folder_path else 1)
    return np.array(images), np.array(labels)

def train_and_save_model(data_dir, model_filename, scaler_filename):
    X, y = load_training_data(data_dir)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    model = KNeighborsClassifier(n_neighbors=5)
    model.fit(X_train, y_train)

    joblib.dump(model, model_filename)
    joblib.dump(scaler, scaler_filename)
    print("Model trained and saved successfully.", file = sys.stderr)  # Print to stderr

def load_model_and_predict(image_path, model_filename, scaler_filename):
    try:
        model = joblib.load(model_filename)
        scaler = joblib.load(scaler_filename)
    except FileNotFoundError as e:
        print(f"Error: Model file not found: {e}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"Error loading model: {e}", file=sys.stderr)
        return None

    image_data = preprocess_image(image_path)
    if image_data is None:
        return None

    image_data = scaler.transform([image_data])
    prediction = model.predict(image_data)
    return prediction[0]


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python predict.py <image_path>", file=sys.stderr)
        sys.exit(1)

    image_path = sys.argv[1]

    # Check if the model exists; if not, train and save it
    if not os.path.exists(MODEL_FILENAME) or not os.path.exists(SCALER_FILENAME):
        print("Training model...", file=sys.stderr)  # Indicate training, print to stderr
        train_and_save_model(DATA_DIR, MODEL_FILENAME, SCALER_FILENAME)
    else:
       # print("Loading pre-trained model...") # No longer printing this to standard output, as this is what has been requested
        pass # Do Nothing instead of printing to stdout

    prediction = load_model_and_predict(image_path, MODEL_FILENAME, SCALER_FILENAME)

    if prediction is not None:
        print(prediction)  # Print the prediction (0 or 1) to stdout
    else:
        sys.exit(1)  # Exit with an error code