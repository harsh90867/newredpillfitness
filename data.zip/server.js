// server.js (Fully Updated with Fixes)
const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const db = require('./db');
const cors = require('cors');
const path = require('path');
const { spawn } = require('child_process');
const multer = require('multer');

// Prediction mapping
const predictionMapping = {
    0: 'Cardio and low-carb diet',
    1: 'Strength training and high-protein diet',
};

const app = express();
const port = 5000;

// Middleware Setup
app.use(bodyParser.json());
app.use(cors());
const upload = multer({ dest: 'uploads/' });

// Serve Static Files
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'uploads')));

// Routes
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/predict', (req, res) => res.sendFile(path.join(__dirname, 'predict.html')));

// Register Endpoint
app.post('/register', async (req, res) => {
    const { username, email, password } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        await db.runAsync('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', [username, email, hashedPassword]);
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        console.error("Registration Error:", error);
        res.status(500).json({ error: 'Failed to register user' });
    }
});

// Login Endpoint
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const row = await db.getAsync('SELECT user_id, username, password FROM users WHERE email = ?', [email]);
        if (!row || !(await bcrypt.compare(password, row.password))) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        res.status(200).json({ message: 'Login successful', user_id: row.user_id, username: row.username });
    } catch (error) {
        console.error("Login Error:", error);
        res.status(500).json({ error: 'Failed to login' });
    }
});

// Image Upload and Prediction Endpoint
app.post('/upload', upload.single('image'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    
    const imagePath = path.join(__dirname, req.file.path);
    
    const pythonProcess = spawn('python', ['predict.py', imagePath], {
        env: { ...process.env, LOKY_MAX_CPU_COUNT: '4' } // Fix for joblib error
    });

    let responseSent = false;
    pythonProcess.stdout.on('data', (data) => {
        if (responseSent) return;
        try {
            const prediction = parseInt(data.toString().trim(), 10);
            const result = predictionMapping[prediction] || 'Unknown prediction';
            res.json({ prediction: result });
            responseSent = true;
        } catch (error) {
            console.error("Error processing Python output:", error);
            if (!responseSent) {
                res.status(500).json({ error: 'Error processing prediction result' });
                responseSent = true;
            }
        }
    });

    pythonProcess.stderr.on('data', (data) => {
        console.error(`Python error: ${data}`);
        if (!responseSent) {
            res.status(500).json({ error: 'Error processing image' });
            responseSent = true;
        }
    });

    pythonProcess.on('close', (code) => {
        if (!responseSent && code !== 0) {
            console.error(`Python script exited with code ${code}`);
            res.status(500).json({ error: 'Python script failed' });
        }
    });
});

// Start Server
app.listen(port, 'localhost', () => {
    console.log(`🚀 Server running at: http://localhost:${port}`);
});