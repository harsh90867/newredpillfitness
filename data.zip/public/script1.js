const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

// Function to get query parameters from URL
function getQueryParam(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

// Check if the action is signup from query parameter
const action = getQueryParam('action');
if (action === 'signup') {
    container.classList.add("active"); // Show signup form
}

if (registerBtn) {
    registerBtn.addEventListener('click', () => {
        container.classList.add("active");
    });
}
if (loginBtn) {
    loginBtn.addEventListener('click', () => {
        container.classList.remove("active");
    });
}

// Login Function
async function loginUser(email, password) {
    try {
        const response = await fetch('http://localhost:5000/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            alert('Login successful!');
            localStorage.setItem('user_id', data.user_id);
            localStorage.setItem('username', data.username);  // Store username
            window.location.href = 'index1.html';  // Redirect after login
        } else {
            alert('Login failed: ' + data.error);
        }
    } catch (error) {
        console.error('Error during login:', error);
        alert('Login failed due to a network error.');
    }
}

// Attach event listener to login form
document.querySelector('.sign-in form')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const email = document.querySelector('.sign-in form input[type="email"]').value;
    const password = document.querySelector('.sign-in form input[type="password"]').value;
    await loginUser(email, password);
});
