import { useSearchParams } from "react-router-dom";
import { useState, useEffect } from "react";

const ResetPasswordPage = () => {
    const [searchParams] = useSearchParams();
    const token = searchParams.get("token");
    const email = searchParams.get("email");
    const [newPassword, setNewPassword] = useState("");

    // ✅ Debugging: Log Token & Email
    useEffect(() => {
        console.log("Token:", token);
        console.log("Email:", email);
    }, [token, email]);

    const handlePasswordReset = async () => {
        console.log("Submitting password reset request...");  // ✅ Debugging Log

        const response = await fetch("http://localhost:5000/reset-password", {  
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ token, newPassword })
        });

        const data = await response.json();
        console.log("Response from server:", data);  // ✅ Debugging Log

        alert(data.message);
    };

    return (
        <div>
            <h2>Reset Your Password</h2>
            <p>Email: {email || "No email found in URL"}</p>
            <p>Token: {token || "No token found in URL"}</p>
            <input
                type="password"
                placeholder="Enter new password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
            />
            <button onClick={handlePasswordReset}>Submit</button>
        </div>
    );
};

export default ResetPasswordPage;
